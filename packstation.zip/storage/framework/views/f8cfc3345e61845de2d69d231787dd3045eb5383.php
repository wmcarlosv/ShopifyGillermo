<a href="<?php echo e(route($routeEdit,$id)); ?>" class="btn btn-info"><i class="fas fa-edit"></i> Edit</a>
<form action="<?php echo e(route($routeDelete, $id)); ?>" method="POST" style="display:inline;">
	<?php echo method_field('DELETE'); ?>
	<?php echo csrf_field(); ?>
	<button class="btn btn-danger delete_record"><i class="fas fa-trash"></i> Delete</button>
</form><?php /**PATH /var/www/html/shopifyConnect/resources/views/admin/partials/action_buttons.blade.php ENDPATH**/ ?>