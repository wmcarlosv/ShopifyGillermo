<?php $__env->startSection('title', 'Edit User'); ?>

<?php $__env->startSection('content'); ?>
	<?php echo $__env->make('admin.partials.errors_messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="row">
		<div class="col-md-12">
			<div class="card card-success">
				<div class="card-header">
					<h3><i class="fas fa-user"></i> Edit User</h3>
				</div>
				<form action="<?php echo e(route('users.update', $user->id)); ?>" method="POST">
					<?php echo method_field('PUT'); ?>
					<?php echo csrf_field(); ?>
					<div class="card-body">
						<div class="form-group">
							<label for="">Name:</label>
							<input type="text" name="name" value="<?php echo e($user->name); ?>" class="form-control" />
						</div>
						<div class="form-group">
							<label for="">Email:</label>
							<input type="text" name="email" value="<?php echo e($user->email); ?>" class="form-control" />
						</div>
						<div class="form-group">
							<label for="">Role:</label>
							<select name="role" id="role" class="form-control">
								<option value="administrator" <?php if($user->role == 'administrator'): ?> selected='selected' <?php endif; ?>>Administrator</option>
								<option value="operator" <?php if($user->role == 'operator'): ?> selected='selected' <?php endif; ?>>Operator</option>
								<option value="courrier" <?php if($user->role == 'courrier'): ?> selected='selected' <?php endif; ?>>Courier</option>
							</select>
						</div>
					</div>
					<div class="card-footer text-right">
						<?php echo $__env->make('admin.partials.form_buttons',['routeCancel'=>'users.index'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
				</form>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/shopifyConnect/resources/views/admin/users/edit.blade.php ENDPATH**/ ?>