<script>
    $(document).ready(function(){
        $("table").DataTable();
        <?php if(Session::get('success')): ?>
            Swal.fire({
              position: 'top-end',
              type: 'success',
              title: '<?php echo e(Session::get("success")); ?>',
              showConfirmButton: false,
              timer: 2500
            });
        <?php endif; ?>

        <?php if(Session::get('errors')): ?>
            Swal.fire({
              position: 'top-end',
              type: 'error',
              title: '<?php echo e(Session::get("error")); ?>',
              showConfirmButton: false,
              timer: 2500
            });
        <?php endif; ?>

        $("body").on('click','button.delete_record', function(){
            if(confirm("Estas seguro de eliminar este Registro?")){
                return true;
            }else{
                return false;
            }
        });
    });
</script><?php /**PATH /var/www/html/ShopifyGuillermo/resources/views/admin/partials/messages.blade.php ENDPATH**/ ?>