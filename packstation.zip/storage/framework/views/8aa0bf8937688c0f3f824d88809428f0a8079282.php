<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/rowreorder/1.2.8/css/rowReorder.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.dataTables.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row" style="margin-top: 10px;">
		<div class="col-md-12">
			<div class="card card-success">
				<div class="card-header">
					<h3><i class="fas fa-file-contract"></i> Orders</h3>
				</div>
				<div class="card-body">
					<table class="table table-bordered table-striped display nowrap" style="width:100%">
						<thead>
							<tr>
								<th>Order Nro</th>
								<th>Order Date</th>
								<th>Currency</th>
								<th>Status</th>
								<th>Customer</th>
								<th>Phone</th>
								<th>Country</th>
								<th>Province</th>
								<th>City</th>
								<th>Address</th>
								<th>Product Name</th>
								<th>Price</th>
								<th>Quantity</th>
								<th>Store</th>
								<th>Courier</th>
								<th>Delivery Date</th>
								<th>Delivery Amount</th>
								<th>Delivery Status</th>
							</tr>
						</thead>
						<tbody id="load_data">
							<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr data-id="<?php echo e($order->id); ?>">
									<td><?php echo e($order->order_no); ?></td>
									<td><span class="get_data_span" id="order_date_<?php echo e($order->id); ?>" data-column='order_date'><?php echo e($order->order_date); ?></span></td>
									<td><span class="get_data_span" id="currency_<?php echo e($order->id); ?>" data-column='currency'><?php echo e($order->currency); ?></span></td>
									<td><span class="get_data_span"  id="status_<?php echo e($order->id); ?>" data-column='status'><?php echo e($order->status); ?></span></td>
									<td><span class="get_data_span"  id="customer_<?php echo e($order->id); ?>" data-column='customer'><?php echo e($order->customer); ?></span></td>
									<td><span class="get_data_span"  id="phone_<?php echo e($order->id); ?>" data-column='phone'><?php echo e($order->phone); ?></span></td>
									<td><span class="get_data_span"  id="country_<?php echo e($order->id); ?>" data-column='country'><?php echo e($order->country); ?></span></td>
									<td><span class="get_data_span"  id="province_<?php echo e($order->id); ?>" data-column='province'><?php echo e($order->province); ?></span></td>
									<td><span class="get_data_span"  id="city_<?php echo e($order->id); ?>" data-column='city'><?php echo e($order->city); ?></span></td>
									<td><span class="get_data_span"  id="address_<?php echo e($order->id); ?>" data-column='address'><?php echo e($order->address); ?></span></td>
									<td><span class="get_data_span"  id="product_name_<?php echo e($order->id); ?>" data-column='product_name'><?php echo e($order->product_name); ?></span></td>
									<td><span class="get_data_span"  id="price_<?php echo e($order->id); ?>" data-column='price'><?php echo e($order->price); ?></span></td>
									<td><span class="get_data_span"  id="qty_<?php echo e($order->id); ?>" data-column='qty'><?php echo e($order->qty); ?></span></td>
									<td><span class="get_data_span"  id="store_<?php echo e($order->id); ?>" data-column='store'><?php echo e($order->store); ?></span></td>
									<td><span class="get_data_span"  id="courier_id_<?php echo e($order->id); ?>" data-column='courier_id'><?php echo e($order->courie_id); ?></span></td>
									<td><span class="get_data_span"  id="delivery_date_<?php echo e($order->id); ?>" data-column='delivery_date'><?php echo e($order->delivery_date); ?></span></td>
									<td><span class="get_data_span"  id="delivery_amount_<?php echo e($order->id); ?>" data-column='delivery_amount'><?php echo e($order->delivery_amount); ?></span></td>
									<td><span class="get_data_span"  id="delivery_status_<?php echo e($order->id); ?>" data-column='delivery_status'><?php echo e($order->delivery_status); ?></span></td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdn.datatables.net/rowreorder/1.2.8/js/dataTables.rowReorder.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>
<script>
	$(document).ready(function(){
		$("table").DataTable({
			responsive: true
		});

		$("body").on('click','span.get_data_span', function(){
			let text = $(this).text();
			let column = $(this).attr("data-column");
			let id = $(this).attr("id");
			let data_id = $(this).parent().parent().attr("data-id");
			$(this).hide();
			$(this).parent().append("<input type='text' data-id='"+data_id+"' value='"+text+"' data-the-id='"+id+"' data-column='"+column+"' style='width:150px;' class='form-control fast-edit' />");
		});

		$("body").on('keypress', 'input.fast-edit', function(event){

			var keycode = (event.keyCode ? event.keyCode : event.which);
			let id = $(this).attr("data-the-id");
			let column = $(this).attr("data-column");
			let data_id = $(this).attr("data-id");

		    if(keycode == '13'){

		    	$.get('/admin/fast-update/'+data_id+'/'+column+'/'+$(this).val(), function(response){
		    		console.log(response);
		    	});

		    	$("#"+id).text($(this).val());
		    	$("#"+id).show();
		    	$(this).remove();
		    }
		});
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/shopifyConnect/resources/views/admin/orders/index.blade.php ENDPATH**/ ?>