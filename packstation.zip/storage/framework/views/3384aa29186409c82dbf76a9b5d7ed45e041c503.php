<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/rowreorder/1.2.8/css/rowReorder.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.dataTables.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row" style="margin-top: 10px;">
		<div class="col-md-12">
			<div class="card card-success">
				<div class="card-header">
					<h3><i class="fas fa-file-contract"></i> Orders</h3>
				</div>
				<div class="card-body">
					<table class="table table-bordered table-striped display nowrap" style="width:100%">
						<thead>
							<tr>
								<th>Nombre del Cliente</th>
								<th>Telenfo del Cliente</th>
								<th>Etiquetas</th>
								<th>Direccion</th>
								<th>Direccion de Envio</th>
								<th>Sku Producto</th>
								<th>Cantidad</th>
								<th>Nombre Producto</th>
								<th>Descuento</th>
								<th>Total Parcial</th>
								<th>Total</th>
								<th>Estado del Pago</th>
								<th>Estado del Pedido</th>
								<th>Nro de Orden</th>
								<th>Fecha</th>
							</tr>
						</thead>
						<tbody id="load_data">
							<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($order->customer); ?></td>
									<td><?php echo e($order->phone); ?></td>
									<td><?php echo e($order->tags); ?></td>
									<td><?php echo e($order->address); ?></td>
									<td><?php echo e($order->shipping_address); ?></td>
									<td><?php echo e($order->product_sku); ?></td>
									<td><?php echo e($order->qty); ?></td>
									<td><?php echo e($order->product_name); ?></td>
									<td><?php echo e($order->discount); ?></td>
									<td><?php echo e($order->parcial_total); ?></td>
									<td><?php echo e($order->total); ?></td>
									<td>
										<?php if($order->payment_status == 'pending'): ?>
											Pendiente
										<?php elseif($order->payment_status == 'paid'): ?>
											Pagado
										<?php endif; ?>
									</td>
									<td><a href="<?php echo e($order->order_status); ?>" target="_blank">Ver Estado</a></td>
									<td><?php echo e($order->order_no); ?></td>
									<td><?php echo e($order->order_date); ?></td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdn.datatables.net/rowreorder/1.2.8/js/dataTables.rowReorder.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>
<script>
	$(document).ready(function(){
		$("table").DataTable({
			responsive: true
		});
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ShopifyGuillermo/resources/views/admin/orders/index.blade.php ENDPATH**/ ?>