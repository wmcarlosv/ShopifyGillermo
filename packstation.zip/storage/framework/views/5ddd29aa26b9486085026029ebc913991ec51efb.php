<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6">
            <div class="info-box">
              <span class="info-box-icon bg-info"><i class="fas fa-users"></i></span>
              <div class="info-box-content">
                <span class="info-box-text">Users</span>
                <span class="info-box-number"><?php echo e($users->count()); ?></span>
              </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="info-box">
              <span class="info-box-icon bg-success"><i class="fas fa-file-contract"></i></span>
              <div class="info-box-content">
                <span class="info-box-text">Orders</span>
                <span class="info-box-number"><?php echo e($orders->count()); ?></span>
              </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <h3>Url WebHook Orders</h3>
            <hr />
            <p>
                <?php echo e(route('get_orders')); ?>

            </p>
            <hr />
            <h3>Url WebHook Orders Update</h3>
            <p>
                <?php echo e(route('update_order')); ?>

            </p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('admin.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ShopifyGuillermo/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>