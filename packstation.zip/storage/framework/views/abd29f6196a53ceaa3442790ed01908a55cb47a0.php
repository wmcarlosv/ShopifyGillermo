<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.partials.errors_messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card card-success">
                <div class="card-header">
                    <h3><i class="fas fa-user"></i> Profile</h3>
                </div>
                <form action="<?php echo e(route('update_profile')); ?>" method="POST">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="">Name:</label>
                            <input type="text" class="form-control" name="name" value="<?php echo e(Auth::user()->name); ?>" />
                        </div>
                        <div class="form-group">
                            <label for="">Email:</label>
                            <input type="text" class="form-control" name="email" value="<?php echo e(Auth::user()->email); ?>" />
                        </div>
                    </div>
                    <div class="card-footer text-right">
                        <?php echo $__env->make('admin.partials.form_buttons',['routeCancel'=>'dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card card-success">
                <div class="card-header">
                    <h3><i class="fas fa-key"></i> Change Password</h3>
                </div>
                <form action="<?php echo e(route('change_password')); ?>" method="POST">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="">Password: </label>
                            <input type="password" name="password" class="form-control" />
                        </div>
                        <div class="form-group">
                            <label for="">Password Confirmation: </label>
                            <input type="password" name="password_confirmation" class="form-control" />
                        </div>
                    </div>
                    <div class="card-footer text-right">
                        <?php echo $__env->make('admin.partials.form_buttons',['routeCancel'=>'dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/shopifyConnect/resources/views/admin/users/profile.blade.php ENDPATH**/ ?>